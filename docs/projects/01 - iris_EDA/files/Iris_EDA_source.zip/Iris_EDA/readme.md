# Iris Data Analysis

Exploratory data analysis of the Iris dataset using Python, pandas, and visualisations.

The project compares measurements across *Iris-setosa*, *Iris-versicolor*, and *Iris-virginica*, focusing on distributions, relationships, and differences between species.

## Project files

- `iris_EDA.ipynb` — analysis and visualisations
- `data/25__iris.csv` — source dataset
- `requirements.txt` — Python dependencies

## Run

Install the dependencies and launch Jupyter Notebook:

```bash
python -m pip install -r requirements.txt
jupyter notebook notebooks/Iris_EDA.ipynb
```

