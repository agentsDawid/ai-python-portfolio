# Titanic Data Analysis

Exploratory data analysis of Titanic passenger records using Python, pandas, Matplotlib, and Seaborn.

The project explores how observed survival rates vary across passenger groups, including passenger class, sex, age, and port of embarkation. It also examines data quality, missing values, distributions, and relationships between variables.

## Project files

- `Titanic_EDA.ipynb` — analysis and visualisations
- `data/26__titanic.csv` — source dataset
- `requirements.txt` — Python dependencies

## Run

Install the dependencies and launch JupyterLab:

```bash
python -m pip install -r requirements.txt
jupyter lab Titanic_EDA.ipynb
```
